unzip and put the froGH folder inside your User Object folder in Grasshopper

Where's the User Object folder?

Open Rhino, then Grasshopper. In Grasshopper, go to File > Special Folders > User Object Folder
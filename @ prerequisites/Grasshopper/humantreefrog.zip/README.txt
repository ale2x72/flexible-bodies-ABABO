copiare tutti i files .gha nella cartella Libraries di Grasshopper

Dov'� la cartella Libraries?

Aprite Rhinoceros e Grasshopper. In Grasshopper, andate su File > Special Folders > Component Folders

Copiate i files nella cartella che si aprir�.

Per finire, riavviate completamente Grasshopper e Rhinoceros